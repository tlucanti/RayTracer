generate_natvis.py
==================

Generate the Natvis debugger visualization file for all supported namespace combinations.

## Usage

```
./generate_natvis.py --version X.Y.Z output_directory/
```
